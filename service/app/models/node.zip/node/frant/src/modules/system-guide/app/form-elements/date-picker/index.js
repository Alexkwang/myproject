angular.module('system-guide-form-elements-date-picker', [])
    .controller('DatePickerCtrl', ['$scope', function($scope){
        $scope.clearDate = function(key){
            $scope[key] = '';
        }
        $scope.date = '2015/01/01 00:00:00'
        $scope.date2 = '2015/06/01 00:00:00'

        $scope.clearData2 = function(){
            console.log('abc');
        }
    }])
