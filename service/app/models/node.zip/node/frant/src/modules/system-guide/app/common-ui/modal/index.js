angular.module('system-guide-common-ui-modal', [])
  .controller('SystemGuideCommonModalDemoCtrl', [
    "$scope", "messager", function($scope, messager) {
      $scope.closeModal = function() {
        $scope.modalDialog = false;
      };
      $scope.openModal = function() {
        $scope.modalDialog = true;
      };
      $scope.save = function() {
        var entity = angular.copy($scope.entity);
        messager.success("Save Successfully.");
        $scope.entity = {};
        $scope.modalDialog = false;
      };
    }
]);
