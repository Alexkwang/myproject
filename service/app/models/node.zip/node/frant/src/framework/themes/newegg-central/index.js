$(document).ready(function(e) {
	//search box
	$('.rua-searchbox>.inputbox>.text').focus(function(e) {
		$(this).parent().addClass('focus');
	});
	$('.rua-searchbox>.inputbox>.text').blur(function(e) {
		$(this).parent().removeClass('focus');
	});
	
	//main menu
	$('.rua-LogoMenu>.logo').click(function(){
		$(this).parent('.rua-LogoMenu').toggleClass('on');
	});
	$('#Level-1 .directory').click(function(e) {
		$('#Level-1').hide('fast');
		$('#Level-2').show('fast');
	});
	$('#Level-2 .back').click(function(e) {
		$('#Level-2').hide('fast');
		$('#Level-1').show('fast');
	});

    $(".nav-list").click(function(e) {
        var link_element = $(e.target).closest("a");
        var sub = link_element.next().get(0);
        if (!$(sub).is(":visible")) {
            var parent_ul = $(sub.parentNode).closest("ul");
            if ($minimized && parent_ul.hasClass("nav-list")) return;
            parent_ul.find("> .open > .submenu").each(function() {
                if (this != sub && !$(this.parentNode).hasClass("active")) {
                    $(this).slideUp(200);
                }
            });
        } else {}
        $(sub).slideToggle(200);
        return false;
    });
});