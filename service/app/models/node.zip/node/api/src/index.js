(function() {
  var app, config, db, log4js, logger, mongoose, path, port, server;

  logger = require("./common/logger");

  config = require("./config/config");

  log4js = require("log4js");

  path = require("path");

  mongoose = require('mongoose');

  port = config.listenPort || 9020;

  log4js.configure(path.join(__dirname, "log4js_configuration.json"), {
    reloadSecs: 60,
    cwd: __dirname
  });

  process.on("uncaughtException", function(err) {
    return logger.error("[uncaught-error] exception: " + err + "\r\nstack: " + err.stack);
  });

  db = mongoose.connect(config.mongodbAddress);

  mongoose.connection.on("error", function(err) {
    return logger.error(err);
  });

  app = require("./config/bootstrap")(__dirname);

  server = app.listen(port, function() {
    return logger.log("Begin listening on port " + port);
  });

}).call(this);
