(function() {
  var Log, logger, mongoose;

  mongoose = require('mongoose');

  Log = mongoose.model('Log');

  logger = require("../common/logger");

  exports.saveLog = function(businessModel) {

    /*
    log = new Log
      DataType: businessModel.DataType
      DataKey:businessModel.DataKey
      LastEditUser:businessModel.LastEditUser
      LastEditDate:businessModel.LastEditDate
      DataValue:businessModel.DataValue
    log.save (err)->
      if err?
        logger.error err
      else
        logger.consoleLog "Save Log Successfully"
     */
  };

}).call(this);
