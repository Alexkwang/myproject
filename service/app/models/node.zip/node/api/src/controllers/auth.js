(function() {
  var Q, Token, config, da, getToken, loginCore, loginViaKeystone, matchAuthAndMenu, matchOthers, mongoose, request, saveTokenInfo, util, validateOAuthReuqest, validateReuqestWhenLogin, _;

  util = require("../common/util");

  mongoose = require('mongoose');

  Token = mongoose.model('Token');

  da = require("../common/dataAccess");

  request = require("request");

  config = require("../config/config");

  Q = require("q");

  _ = require('lodash');

  exports.autoLogin = function(req, res, next) {
    var lastLoginDate, tokenInfo;
    tokenInfo = req.tokenInfo;
    if (tokenInfo == null) {
      next(new Error("Auto login failed."));
    }
    if ((tokenInfo != null) && (tokenInfo.Token != null)) {
      lastLoginDate = (new Date() - tokenInfo.LoginDate) / (1000 * 60 * 60 * 24);
      if (lastLoginDate > 30) {
        return tokenInfo.remove(function(err) {
          return next(new Error("Auto login failed."));
        });
      } else {
        return Q.all([da.getMenus(), da.getToolbar(), da.getWidget(), da.getGlobalSearch()]).then(function(results) {
          var globalSearch, menus, toolbars, widgets;
          menus = results[0];
          toolbars = results[1];
          widgets = results[2];
          globalSearch = results[3];
          if (((menus != null) && menus.LastEditDate > tokenInfo.LoginDate) || ((toolbars != null) && toolbars.LastEditDate > tokenInfo.LoginDate) || ((widgets != null) && widgets.LastEditDate > tokenInfo.LoginDate) || ((globalSearch != null) && globalSearch.LastEditDate > tokenInfo.LoginDate)) {
            return loginCore(tokenInfo, req, res, next);
          } else {
            tokenInfo.AuthData.UserInfo.IpAddress = req.connection.remoteAddress;
            res.json(tokenInfo.AuthData);
            return saveTokenInfo(tokenInfo, req.tokenInfo);
          }
        }, function(err) {
          return next(new Error("Auto login failed. " + err));
        });
      }
    } else {
      return next(new Error("Auto login failed."));
    }
  };

  exports.logout = function(req, res, next) {
    var tokenInfo;
    tokenInfo = req.tokenInfo;
    if (tokenInfo == null) {
      res.statusCode = 200;
      return res.end();
    } else {
      return tokenInfo.remove(function(err) {
        if (err != null) {
          return next(new Error("Logout failed. " + err));
        } else {
          res.statusCode = 200;
          return res.end();
        }
      });
    }
  };

  exports.login = function(req, res, next) {
    var loginUser;
    if (validateReuqestWhenLogin(req) === false) {
      return next(new Error("User name and password is required."));
    } else {
      loginUser = {
        UserName: req.body.UserName,
        Password: req.body.Password,
        ApplicationIds: req.body.ApplicationIds
      };
      return loginCore(loginUser, req, res, next);
    }
  };

  loginCore = function(loginUser, req, res, next) {
    return Q.all([loginViaKeystone(loginUser), da.getMenus(), da.getToolbar(), da.getWidget(), da.getGlobalSearch()]).then(function(results) {
      var menuResult, menus, token, userInfo;
      userInfo = results[0];
      userInfo.toolbars = results[2] != null ? results[2].DataValue : [];
      userInfo.widgets = results[3] != null ? results[3].DataValue : [];
      userInfo.globalSearch = results[4] != null ? results[4].DataValue : [];
      menuResult = results[1] != null ? results[1].DataValue : null;
      if ((userInfo == null) || (userInfo.LoginResult == null) || userInfo.LoginResult === false) {
        return next(new Error("Login failed."));
      } else {
        userInfo.UserInfo.IpAddress = req.connection.remoteAddress;
        if (userInfo.Functions != null) {
          menus = (menuResult != null) && (menuResult.Child != null) ? menuResult.Child : [];
          userInfo.MenuData = matchAuthAndMenu(userInfo.Functions, menus);
        }
        if (userInfo.toolbars.length > 0) {
          userInfo.toolbars = matchOthers(userInfo.Functions, userInfo.toolbars);
        }
        if (userInfo.widgets.length > 0) {
          userInfo.widgets = matchOthers(userInfo.Functions, userInfo.widgets);
        }
        if (userInfo.globalSearch.length > 0) {
          userInfo.globalSearch = matchOthers(userInfo.Functions, userInfo.globalSearch);
        }
        if (loginUser.Token == null) {
          token = getToken(userInfo.UserInfo.UserID);
          res.setHeader("x-newkit-token", token);
          loginUser.Token = token;
        }
        loginUser.AuthData = userInfo;
        saveTokenInfo(loginUser, req.tokenInfo);
        return res.json(userInfo);
      }
    }, function(err) {
      return next(new Error("Login failed. " + err));
    });
  };

  loginViaKeystone = function(loginUser) {
    var deferred, options, requestBody;
    deferred = Q.defer();
    requestBody = JSON.stringify(loginUser);
    options = {
      url: config.keystoneAuthAPI,
      method: "POST",
      headers: {
        "content-type": "application/json",
        "accept": "application/json"
      },
      body: requestBody
    };
    request(options, function(error, response, body) {
      if ((error == null) && response.statusCode === 200) {
        return deferred.resolve(JSON.parse(body));
      } else {
        return deferred.reject(error);
      }
    });
    return deferred.promise;
  };

  validateReuqestWhenLogin = function(req) {
    if ((req.body.UserName == null) || (req.body.Password == null) || (req.body.ApplicationIds == null) || req.body.ApplicationIds.length === 0) {
      return false;
    }
    return true;
  };

  matchAuthAndMenu = function(functions, menus) {
    var find, item, menu, results, _i, _j, _k, _len, _len1, _len2;
    for (_i = 0, _len = menus.length; _i < _len; _i++) {
      menu = menus[_i];
      if ((menu.AuthKey != null) && menu.AuthKey !== "") {
        find = void 0;
        for (_j = 0, _len1 = functions.length; _j < _len1; _j++) {
          item = functions[_j];
          if (item.ApplicationId === menu.ApplicationId && item.Name === menu.AuthKey) {
            find = item;
          }
        }
        if (find == null) {
          menu.SubMenus = null;
          menu.AuthResult = false;
        } else {
          menu.AuthResult = true;
        }
      } else {
        menu.AuthResult = true;
      }
      if (!menu.IsActived) {
        menu.AuthResult = false;
      }
      if ((menu.SubMenus != null) && menu.SubMenus.length > 0) {
        menu.SubMenus = matchAuthAndMenu(functions, menu.SubMenus);
        if (menu.SubMenus === null && !menu.Url) {
          menu.AuthResult = false;
        }
      } else if (!menu.Url) {
        menu.AuthResult = false;
      }
    }
    results = [];
    for (_k = 0, _len2 = menus.length; _k < _len2; _k++) {
      menu = menus[_k];
      if (menu.AuthResult === true) {
        results.push(menu);
      }
    }
    if (results.length === 0) {
      results = null;
    }
    return results;
  };

  matchOthers = function(functions, data) {
    var f, find, item, results, _i, _j, _k, _len, _len1, _len2;
    if (functions == null) {
      return [];
    }
    for (_i = 0, _len = data.length; _i < _len; _i++) {
      item = data[_i];
      if ((item.AuthKey != null) && item.AuthKey !== "") {
        find = void 0;
        for (_j = 0, _len1 = functions.length; _j < _len1; _j++) {
          f = functions[_j];
          if (f.ApplicationId === item.ApplicationId && f.Name === item.AuthKey) {
            find = f;
          }
        }
        if (find == null) {
          item.AuthResult = false;
        } else {
          item.AuthResult = true;
        }
      } else {
        item.AuthResult = true;
      }
      if (!item.IsActived) {
        item.AuthResult = false;
      }
    }
    results = [];
    for (_k = 0, _len2 = data.length; _k < _len2; _k++) {
      item = data[_k];
      if (item.AuthResult === true) {
        results.push(item);
      }
    }
    return results;
  };

  saveTokenInfo = function(loginUser, oldToken) {
    var newToken;
    loginUser.Password = util.toBase64String(loginUser.Password);
    loginUser.LoginDate = new Date();
    if (oldToken != null) {
      newToken = _.extend(oldToken, loginUser);
    } else {
      newToken = new Token(loginUser);
    }
    return newToken.save(function(err) {
      if (err != null) {
        return console.log(err);
      }
    });
  };

  getToken = function(userId) {
    var key;
    key = userId + new Date();
    return util.getHash(key);
  };

  exports.oauthToken = function(req, res, next) {
    var oauthRequest, options;
    if (!validateOAuthReuqest(req)) {
      next(new Error("User name and client id is required."));
      return;
    }
    oauthRequest = {
      username: req.body.username,
      client_id: req.body.client_id,
      grant_type: "password"
    };
    options = {
      url: config.authServerAddress,
      method: "POST",
      headers: {
        "content-type": "application/json",
        "accept": "application/json"
      },
      body: JSON.stringify(oauthRequest)
    };
    return request(options, function(error, response, body) {
      if (error != null) {
        return next(error);
      } else if (response.statusCode >= 400) {
        return next(new Error("Get OAuth token failed."));
      } else {
        return res.json(JSON.parse(body));
      }
    });
  };

  validateOAuthReuqest = function(req) {
    if ((req.body.username == null) || (req.body.client_id == null)) {
      return false;
    }
    return true;
  };

}).call(this);
