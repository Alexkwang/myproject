(function() {
  var config, fs, mime, request, util, uuid;

  fs = require("fs");

  request = require("request");

  config = require("../config/config");

  util = require("../common/util");

  uuid = require("node-uuid");

  mime = require("mime");

  exports.upload = function(req, res, next) {
    var filename, imageData, matches, requestOption, url;
    matches = req.body.file.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    imageData = {};
    if (matches.length !== 3) {
      next(new Error("Invalid input string"));
      return;
    }
    imageData.type = matches[1];
    imageData.data = new Buffer(matches[2], "base64");
    filename = "screen_" + uuid.v1() + "." + mime.extension(imageData.type);
    url = util.getDFISUrl(filename, true);
    requestOption = {
      url: url,
      headers: {
        "content-type": imageData.type,
        accept: "application/json"
      },
      body: imageData.data
    };
    return request.post(requestOption, function(error, response, body) {
      if (error != null) {
        return next(error);
      } else {
        return res.json({
          file: util.getDFISUrl(filename)
        });
      }
    });
  };

}).call(this);
