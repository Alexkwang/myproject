(function() {
  var Framework, config, da, getAllModules, log, mongoose, saveMenu, _;

  mongoose = require('mongoose');

  da = require("../common/dataAccess");

  Framework = mongoose.model('Framework');

  config = require("../config/config");

  log = require("./log");

  _ = require('lodash');

  exports.getUrls = function(req, res, next) {
    return da.getMenus().then(function(data) {
      if (data != null) {
        return res.json(data.DataValue.Urls);
      } else {
        return res.end();
      }
    }, function(err) {
      return next(new Error("Get menus failed. " + err));
    });
  };

  exports.getMenus = function(req, res, next) {
    return da.getMenus().then(function(data) {
      if (data != null) {
        return res.json(data.DataValue.Child);
      } else {
        return res.end();
      }
    }, function(err) {
      return next(new Error("Get menus failed. " + err));
    });
  };

  exports.setMenus = function(req, res, next) {
    return saveMenu(req.body, req.tokenInfo.UserName, function(err) {
      if (err != null) {
        return next(new Error("Save menus failed. " + err));
      } else {
        res.statusCode = 200;
        return res.end();
      }
    });
  };

  saveMenu = function(menuData, editUser, callback) {
    var menus, urls;
    urls = {};
    getAllModules(urls, menuData);
    menus = {
      DataType: "menu",
      LastEditUser: editUser,
      LastEditDate: new Date(),
      DataValue: {
        Child: menuData,
        Urls: urls
      }
    };
    return da.getMenus().then(function(oldMenu) {
      var newMenu;
      if (oldMenu != null) {
        newMenu = _.extend(oldMenu, menus);
        return newMenu.save(function(err) {
          if (err != null) {
            return callback(err);
          } else {
            log.saveLog(newMenu);
            return callback();
          }
        });
      } else {
        menus = new Framework(menus);
        return menus.save(function(err) {
          if (err != null) {
            return callback(err);
          } else {
            log.saveLog(menus);
            return callback();
          }
        });
      }
    }, function(err) {
      return callback(err);
    });
  };

  getAllModules = function(urls, menus, next) {
    var lan, menu, _i, _j, _len, _len1, _ref, _results;
    _results = [];
    for (_i = 0, _len = menus.length; _i < _len; _i++) {
      menu = menus[_i];
      if (menu.Url != null) {
        if (urls[menu.Url] != null) {
          next(new Error("Url duplicated for '" + menu.Url + "'"));
        } else {
          urls[menu.Url] = {
            Url: menu.Url,
            ApplicationdId: menu.ApplicationId,
            AuthKey: menu.AuthKey,
            Icon: menu.Icon
          };
          _ref = config.languages;
          for (_j = 0, _len1 = _ref.length; _j < _len1; _j++) {
            lan = _ref[_j];
            urls[menu.Url][lan] = menu[lan];
          }
        }
      }
      if ((menu.SubMenus != null) && menu.SubMenus.length > 0) {
        _results.push(getAllModules(urls, menu.SubMenus, next));
      } else {
        _results.push(void 0);
      }
    }
    return _results;
  };

  exports.initMenu = function(menuData, editUser, callback) {
    return saveMenu(menuData, editUser, callback);
  };

}).call(this);
