(function() {
  var busboy, config, del, extractTarPackage, fs, getDownloadPath, getUploadPath, mime, path, request, tar, util, uuid;

  fs = require("fs");

  request = require("request");

  config = require("../config/config");

  util = require("../common/util");

  uuid = require("node-uuid");

  mime = require("mime");

  path = require("path");

  tar = require("tar");

  del = require("del");

  busboy = require('connect-busboy');

  exports.deploy = function(req, res, next) {
    var downloadUrl, fileName;
    fileName = req.body.fileName;
    if (!fileName) {
      if (!fileName) {
        next(new Error("fileName is required."));
      }
      return;
    }
    downloadUrl = util.getDFISUrl(fileName) + "?t=" + util.getHash(new Date().toString());
    return request(downloadUrl).on("error", function(err) {
      return next(err);
    }).on("end", function() {
      return extractTarPackage(getDownloadPath(fileName), res, next);
    }).pipe(fs.createWriteStream(getDownloadPath(fileName)));
  };

  getDownloadPath = function(fileName) {
    var downloadPath;
    downloadPath = path.join(config.downloadPath, fileName);
    return downloadPath;
  };

  getUploadPath = function(fileName) {
    var downloadPath;
    downloadPath = path.join(config.uploadPath, fileName);
    return downloadPath;
  };

  extractTarPackage = function(fileName, res, next) {
    var extractor;
    extractor = tar.Extract({
      path: config.newkitModulePath
    }).on('error', function(err) {
      return next(err);
    }).on('end', function() {
      return res.status(200).end();
    });
    return fs.createReadStream(fileName).on('error', function(err) {
      return next(err);
    }).pipe(extractor);
  };

  exports.upload = function(req, res, next) {
    req.pipe(req.busboy);
    return req.busboy.on("file", function(fieldname, file, filename) {
      var fsStream, url;
      url = util.getDFISUrl(filename, true);
      fsStream = request.post(url);
      fsStream.on("error", function(error) {
        return next(error);
      });
      fsStream.on("end", function() {
        return res.end("OK");
      });
      return file.pipe(fsStream);
    });
  };

}).call(this);
