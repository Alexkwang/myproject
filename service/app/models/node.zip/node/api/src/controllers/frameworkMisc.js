(function() {
  var Framework, da, getData, log, mongoose, saveData, _;

  mongoose = require('mongoose');

  da = require("../common/dataAccess");

  Framework = mongoose.model('Framework');

  log = require("./log");

  _ = require('lodash');

  exports.getWidget = function(req, res, next) {
    return getData(da.getWidget, res, next);
  };

  exports.getToolbar = function(req, res, next) {
    return getData(da.getToolbar, res, next);
  };

  exports.getGlobalSearch = function(req, res, next) {
    return getData(da.getGlobalSearch, res, next);
  };

  getData = function(func, res, next) {
    return func().then(function(data) {
      if (data != null) {
        return res.json(data.DataValue);
      } else {
        return res.end();
      }
    }, function(err) {
      return next(new Error("Get data failed. " + err));
    });
  };

  exports.setWidget = function(req, res, next) {
    return saveData(req.body, "widget", req.tokenInfo.UserName, res, next);
  };

  exports.setToolbar = function(req, res, next) {
    return saveData(req.body, "toolbar", req.tokenInfo.UserName, res, next);
  };

  exports.setGlobalSearch = function(req, res, next) {
    return saveData(req.body, "globalsearch", req.tokenInfo.UserName, res, next);
  };

  saveData = function(dataValue, dataType, editUser, res, next) {
    var model;
    model = {
      DataType: dataType,
      LastEditUser: editUser,
      LastEditDate: new Date(),
      DataValue: dataValue
    };
    return da.getData(dataType).then(function(lodModel) {
      var newModel;
      if (lodModel != null) {
        newModel = _.extend(lodModel, model);
        return newModel.save(function(err) {
          if (err != null) {
            return next(new Error("Save data failed. " + err));
          } else {
            log.saveLog(newModel);
            return res.end();
          }
        });
      } else {
        model = new Framework(model);
        return model.save(function(err) {
          if (err != null) {
            return next(new Error("Save data failed. " + err));
          } else {
            log.saveLog(model);
            return res.end();
          }
        });
      }
    }, function(err) {
      return next(new Error("Save data failed. " + err));
    });
  };

}).call(this);
