(function() {
  var auth, config, hasAuthorization;

  auth = require("../controllers/auth");

  config = require("../config/config");

  hasAuthorization = require("../common/hasAuthorization");

  module.exports = function(app) {
    app.post("" + config.apiPrefix + "/autologin", auth.autoLogin);
    app.post("" + config.apiPrefix + "/login", auth.login);
    app.post("" + config.apiPrefix + "/logout", auth.logout);
    app.post("" + config.apiPrefix + "/logout", auth.logout);
    return app.post("" + config.apiPrefix + "/token", hasAuthorization, auth.oauthToken);
  };

}).call(this);
