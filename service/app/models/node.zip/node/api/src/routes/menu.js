(function() {
  var config, hasAuthorization, menus;

  menus = require("../controllers/menu");

  hasAuthorization = require("../common/hasAuthorization");

  config = require("../config/config");

  module.exports = function(app) {
    app.get("" + config.apiPrefix + "/menu", menus.getMenus);
    app.post("" + config.apiPrefix + "/menu", hasAuthorization, menus.setMenus);
    return app.get("" + config.apiPrefix + "/menu/urls", menus.getUrls);
  };

}).call(this);
