(function() {
  var config, deployCtrl;

  deployCtrl = require("../controllers/deploy");

  config = require("../config/config");

  module.exports = function(app) {
    app.post("" + config.apiPrefix + "/deploy", deployCtrl.deploy);
    return app.post("" + config.apiPrefix + "/deploy/upload", deployCtrl.upload);
  };

}).call(this);
