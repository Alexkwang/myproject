(function() {
  var config, frameworkController, hasAuthorization;

  frameworkController = require("../controllers/frameworkMisc");

  hasAuthorization = require("../common/hasAuthorization");

  config = require("../config/config");

  module.exports = function(app) {
    app.get("" + config.apiPrefix + "/widget", frameworkController.getWidget);
    app.post("" + config.apiPrefix + "/widget", hasAuthorization, frameworkController.setWidget);
    app.get("" + config.apiPrefix + "/toolbar", frameworkController.getToolbar);
    app.post("" + config.apiPrefix + "/toolbar", hasAuthorization, frameworkController.setToolbar);
    app.get("" + config.apiPrefix + "/globalsearch", frameworkController.getGlobalSearch);
    return app.post("" + config.apiPrefix + "/globalsearch", hasAuthorization, frameworkController.setGlobalSearch);
  };

}).call(this);
