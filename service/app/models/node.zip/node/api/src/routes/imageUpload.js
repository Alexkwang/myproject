(function() {
  var config, imageController;

  imageController = require("../controllers/image");

  config = require("../config/config");

  module.exports = function(app) {
    return app.post("" + config.apiPrefix + "/upload-image", imageController.upload);
  };

}).call(this);
