(function() {
  var config, frameworkController, initData, initMenu, initToolbar, initWidget, menuController;

  menuController = require("../controllers/menu");

  frameworkController = require("../controllers/frameworkMisc");

  initData = require("../test/initData");

  config = require("../config/config");

  module.exports = function(app) {
    app.post("" + config.apiPrefix + "/system-init-menu", initMenu);
    app.post("" + config.apiPrefix + "/system-init-toolbar", initToolbar);
    return app.post("" + config.apiPrefix + "/system-init-widget", initWidget);
  };

  initMenu = function(req, res, next) {
    req.tokenInfo = {};
    req.tokenInfo.UserName = "system";
    req.body = initData.menuData;
    return menuController.setMenus(req, res, next);
  };

  initToolbar = function(req, res, next) {
    req.tokenInfo = {};
    req.tokenInfo.UserName = "system";
    req.body = initData.toolbarData;
    return frameworkController.setToolbar(req, res, next);
  };

  initWidget = function(req, res, next) {
    req.tokenInfo = {};
    req.tokenInfo.UserName = "system";
    req.body = initData.widgetData;
    return frameworkController.setWidget(req, res, next);
  };

}).call(this);
