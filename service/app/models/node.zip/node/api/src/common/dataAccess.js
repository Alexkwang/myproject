(function() {
  var Framework, Q, Token, getFrameworkData, logger, mongoose;

  mongoose = require('mongoose');

  Framework = mongoose.model('Framework');

  Token = mongoose.model('Token');

  logger = require("./logger");

  Q = require("q");

  exports.getMenus = function() {
    return getFrameworkData("menu");
  };

  exports.getWidget = function() {
    return getFrameworkData("widget");
  };

  exports.getToolbar = function() {
    return getFrameworkData("toolbar");
  };

  exports.getGlobalSearch = function() {
    return getFrameworkData("globalsearch");
  };

  exports.getData = function(dataType) {
    return getFrameworkData(dataType);
  };

  getFrameworkData = function(dataType) {
    var deferred;
    deferred = Q.defer();
    Framework.findOne({
      DataType: dataType
    }, function(err, data) {
      if (err != null) {
        return deferred.reject(err);
      } else {
        return deferred.resolve(data);
      }
    });
    return deferred.promise;
  };

  exports.getToken = function(tokenInfo) {
    var deferred;
    deferred = Q.defer();
    Token.findOne({
      Token: tokenInfo
    }, function(err, data) {
      if (err != null) {
        return deferred.reject(err);
      } else {
        return deferred.resolve(data);
      }
    });
    return deferred.promise;
  };

}).call(this);
