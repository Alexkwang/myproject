(function() {
  var domain, logger;

  domain = require("domain");

  logger = require("./logger");

  module.exports = function() {
    return function(req, res, next) {
      var d;
      d = domain.create();
      d.add(req);
      d.add(res);
      d.on("error", function(err) {
        d._throwErrorCount = (d._throwErrorCount || 0) + 1;
        if (d._throwErrorCount > 1) {
          logger.error("[domain-error] " + req.method + " " + req.url + " throw error " + d._throwErrorCount + " times");
          logger.error(err);
          return;
        }
        res.setHeader("Connection", "close");
        return next(err);
      });
      return d.run(next);
    };
  };

}).call(this);
