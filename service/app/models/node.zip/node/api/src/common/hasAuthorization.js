(function() {
  module.exports = function(req, res, next) {
    var tokenInfo;
    tokenInfo = req.tokenInfo;
    if (tokenInfo == null) {
      return next(new Error("User is not authorized."));
    } else {
      return next();
    }
  };

}).call(this);
