(function() {
  var da, util;

  da = require("../common/dataAccess");

  util = require("./util");

  module.exports = function() {
    return function(req, res, next) {
      var token;
      token = req.headers["x-newkit-token"];
      if (token == null) {
        return next();
      } else {
        return da.getToken(token).then(function(tokenInfo) {
          if (tokenInfo != null) {
            req.tokenInfo = tokenInfo;
            req.tokenInfo.Password = util.fromBase64String(tokenInfo.Password);
          }
          return next();
        }, function(error) {
          return next(error);
        });
      }
    };
  };

}).call(this);
