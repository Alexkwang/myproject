(function() {
  var busboy, config, cors, express, fs;

  fs = require("fs");

  express = require('express');

  cors = require('cors');

  config = require("../config/config");

  busboy = require('connect-busboy');

  module.exports = function(appPath) {
    var app, corsOption, domainError, models_path, routes_path, token;
    models_path = appPath + "/models";
    fs.readdirSync(models_path).forEach(function(file) {
      var newPath, stat;
      newPath = models_path + "/" + file;
      stat = fs.statSync(newPath);
      if (stat.isFile()) {
        if (/(.*)\.(js$)/.test(file)) {
          return require(newPath);
        }
      }
    });
    token = require('../common/token');
    domainError = require("../common/domainError");
    corsOption = {
      exposedHeaders: "x-newkit-token"
    };
    app = express();
    app.configure(function() {
      app.use(express.urlencoded({
        limit: '10mb'
      }));
      app.use(express.json({
        limit: '10mb'
      }));
      app.use(express.methodOverride());
      app.use(cors(corsOption));
      app.use(domainError());
      app.use(busboy());
      app.use(token());
      app.use(app.router);
      return app.use(function(err, req, res, next) {
        res.statusCode = 500;
        res.json({
          Message: err.message,
          Stack: config.debug === true ? err.stack : void 0
        });
        return res.end();
      });
    });
    routes_path = appPath + "/routes";
    fs.readdirSync(routes_path).forEach(function(file) {
      var newPath, stat;
      newPath = routes_path + "/" + file;
      stat = fs.statSync(newPath);
      if (stat.isFile()) {
        if (/(.*)\.(js$)/.test(file)) {
          return require(newPath)(app);
        }
      }
    });
    return app;
  };

}).call(this);
