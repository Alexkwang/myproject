(function() {
  var config, env, exports;

  config = {};

  env = "[replace_env]";

  config.listenPort = 8201;

  config.dfis_group = "newkit";

  config.dfis_type = "attachment";

  config.debug = true;

  config.languages = ["en-us", "zh-cn", "zh-tw"];

  if (env === "GDEV") {
    config.mongodbAddress = "mongodb://10.16.75.24/newkit";
    config.keystoneAuthAPI = "http://10.16.75.24:3000/framework/v1/keystone/login";
    config.authServerAddress = "http://10.16.75.24:3000/auth/v1/authorize?trusted=true";
    config.frameworkAppId = "1f48a705-b734-476c-b32b-29359177c122";
    config.apiPrefix = "";
    config.dfis_uploadUrl = "http://10.1.24.144:8021";
    config.dfis_downloadUrl = "http://10.1.24.144:8001";
    config.downloadPath = "/var/lib/newkit_api/deploy/downloads";
    config.newkitModulePath = "/var/lib/newkit_api/deploy/deploys";
  } else if (env === "GQC") {
    config.mongodbAddress = "mongodb://10.1.24.130/newkit";
    config.keystoneAuthAPI = "http://10.1.24.145:3000/framework/v1/keystone/login";
    config.authServerAddress = "http://10.1.24.145:3000/auth/v1/authorize?trusted=true";
    config.frameworkAppId = "4b60ee12-3754-4992-9ad5-019a90534302";
    config.apiPrefix = "/newegg-central-2/v1";
    config.dfis_uploadUrl = "http://10.1.24.144:8021";
    config.dfis_downloadUrl = "http://10.1.24.144:8001";
    config.downloadPath = "/opt/app/newegg-central-2.0-api/deploy/downloads";
    config.newkitModulePath = "/opt/app/newegg-central-2.0/modules";
  } else if (env === "PRD") {
    config.mongodbAddress = "mongodb://10.1.54.110/newkit,10.1.54.111/newkit?readPreference=primaryPreferred";
    config.keystoneAuthAPI = "http://apis.newegg.org/framework/v1/keystone/login";
    config.authServerAddress = "http://apis.newegg.org/auth/v1/authorize?trusted=true";
    config.frameworkAppId = "0915dbb7-27f5-4740-9e50-2bc9c0fb3378";
    config.apiPrefix = "/newegg-central-2/v1";
    config.dfis_uploadUrl = "http://neg-app-dfis:8200";
    config.dfis_downloadUrl = "http://neg-app-img";
    config.downloadPath = "/opt/app/newegg-central-2.0-api/deploy/downloads";
    config.newkitModulePath = "/opt/app/newegg-central-2.0/modules";
  } else if (env === "PRDTESTING") {
    config.mongodbAddress = "mongodb://10.1.54.110/newkit_test,10.1.54.111/newkit_test?readPreference=primaryPreferred";
    config.keystoneAuthAPI = "http://sandboxapis.newegg.org/framework/v1/keystone/login";
    config.authServerAddress = "http://apis.newegg.org/auth/v1/authorize?trusted=true";
    config.frameworkAppId = "0915dbb7-27f5-4740-9e50-2bc9c0fb3378";
    config.apiPrefix = "/newegg-central-2/v1";
    config.dfis_uploadUrl = "http://neg-app-dfis:8200";
    config.dfis_downloadUrl = "http://neg-app-img";
    config.downloadPath = "/opt/app/newegg-central-2.0-api/deploy/downloads";
    config.newkitModulePath = "/opt/app/newegg-central-2.0/modules";
  }

  exports = module.exports = config;

}).call(this);
