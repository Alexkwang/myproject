(function() {
  var FrameworkSchema, Schema, mongoose;

  mongoose = require('mongoose');

  Schema = mongoose.Schema;

  FrameworkSchema = new Schema({
    DataType: String,
    DataKey: String,
    LastEditUser: String,
    LastEditDate: {
      type: Date,
      "default": Date.now
    },
    DataValue: {}
  });

  mongoose.model("Framework", FrameworkSchema);

}).call(this);
