(function() {
  var Schema, TokenSchema, mongoose;

  mongoose = require('mongoose');

  Schema = mongoose.Schema;

  TokenSchema = new Schema({
    UserName: String,
    Password: String,
    Token: String,
    LoginDate: Date,
    ApplicationIds: [],
    AuthData: {}
  });

  mongoose.model("Token", TokenSchema);

}).call(this);
