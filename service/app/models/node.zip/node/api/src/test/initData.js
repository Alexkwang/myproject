(function() {
  var config;

  config = require("../config/config");

  module.exports.menuData = [
    {
      "zh-tw": "控制麵板",
      "zh-cn": "控制面板",
      "en-us": "Control Panel",
      "ApplicationId": "" + config.frameworkAppId,
      "IsActived": true,
      "IsVisible": true,
      "Url": "/control-panel",
      "Icon": "icon-cogs",
      "SubMenus": [
        {
          "SubMenus": [
            {
              "zh-tw": "菜單",
              "zh-cn": "菜单",
              "en-us": "Menu",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Url": "/system/menus",
              "Icon": "icon-archive",
              "Description": "this is description"
            }, {
              "Url": "/system/toolbars",
              "zh-tw": "工具欄",
              "zh-cn": "工具栏",
              "en-us": "Toolbar",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Icon": "icon-truck"
            }, {
              "Url": "/system/widgets",
              "zh-tw": "部件",
              "zh-cn": "部件",
              "en-us": "Widgets",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Icon": "icon-tablet"
            }, {
              "Url": "/system/global-search",
              "zh-tw": "全局搜索",
              "zh-cn": "全局搜索",
              "en-us": "Global Search",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Icon": "icon-search"
            }
          ],
          "zh-tw": "維護",
          "zh-cn": "维护",
          "en-us": "Maintain",
          "ApplicationId": "" + config.frameworkAppId,
          "IsActived": true,
          "IsVisible": true,
          "Icon": "icon-wrench"
        }, {
          "IsVisible": true,
          "IsActived": true,
          "ApplicationId": "" + config.frameworkAppId,
          "en-us": "Global Configuration",
          "zh-cn": "全局配置维护",
          "zh-tw": "全局配置維護",
          "Url": "/system/global-configuration",
          "Icon": "icon-edit"
        }, {
          "SubMenus": [
            {
              "Url": "/system-guide/button",
              "zh-tw": "Buttons",
              "zh-cn": "Buttons",
              "en-us": "Buttons",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Icon": "icon-double-angle-right"
            }, {
              "Url": "/system-guide/icon",
              "zh-tw": "Icon",
              "zh-cn": "Icon",
              "en-us": "Icon",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Icon": "icon-double-angle-right"
            }, {
              "Icon": "icon-double-angle-right",
              "IsVisible": true,
              "IsActived": true,
              "ApplicationId": "" + config.frameworkAppId,
              "en-us": "Pure Css",
              "zh-cn": "Pure Css",
              "zh-tw": "Pure Css",
              "Url": "/system-guide/pure-css"
            }, {
              "en-us": "Common UI",
              "zh-cn": "Common UI",
              "zh-tw": "Common UI",
              "Url": "/system-guide/common-ui",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Icon": "icon-double-angle-right"
            }, {
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Icon": "icon-double-angle-right",
              "en-us": "Form Elements",
              "zh-cn": "Form Elements",
              "zh-tw": "Form Elements",
              "Url": "/system-guide/form-elements"
            }, {
              "Url": "/system-guide/validation",
              "zh-tw": "Validation",
              "zh-cn": "Validation",
              "en-us": "Validation",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Icon": "icon-double-angle-right"
            }, {
              "Url": "/system-guide/table",
              "zh-tw": "Table",
              "zh-cn": "Table",
              "en-us": "Table",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Icon": "icon-double-angle-right"
            }, {
              "Url": "/system-guide/grid",
              "zh-tw": "Grid",
              "zh-cn": "Grid",
              "en-us": "Grid",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Icon": "icon-double-angle-right"
            }, {
              "Url": "/system-guide/treeview",
              "zh-tw": "Treeview",
              "zh-cn": "Treeview",
              "en-us": "Treeview",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Icon": "icon-double-angle-right"
            }
          ],
          "zh-tw": "UI Guide",
          "zh-cn": "UI Guide",
          "en-us": "UI Guide",
          "ApplicationId": "" + config.frameworkAppId,
          "IsActived": true,
          "IsVisible": true,
          "Icon": "icon-book"
        }, {
          "zh-tw": "Upload",
          "zh-cn": "Upload",
          "en-us": "Upload",
          "SubMenus": [
            {
              "en-us": "Single File Upload",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Url": "/system-tutorials/single-upload",
              "Icon": "icon-plus"
            }, {
              "en-us": "Multi File Upload",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Url": "/system-tutorials/multi-upload",
              "Icon": "icon-plus"
            }, {
              "en-us": "Multi File Upload (Dropzone)",
              "ApplicationId": "" + config.frameworkAppId,
              "IsActived": true,
              "IsVisible": true,
              "Url": "/system-tutorials/multi-upload-dropzone",
              "Icon": "icon-plus"
            }
          ],
          "ApplicationId": "" + config.frameworkAppId,
          "IsActived": true,
          "IsVisible": true,
          "Icon": "icon-cloud-download"
        }
      ]
    }
  ];

  module.exports.toolbarData = [
    {
      "ApplicationId": "" + config.frameworkAppId,
      "color": "blue",
      "tplUrl": "/toolbars/system-translate/index.tpl.html",
      "zh-tw": "Translate",
      "zh-cn": "Translate",
      "en-us": "Translate",
      "IsActived": true
    }
  ];

  module.exports.widgetData = [
    {
      "color": "widget-color-dark",
      "IsActived": true,
      "en-us": "Most Used",
      "zh-cn": "Most Used",
      "zh-tw": "Most Used",
      "tplUrl": "/widgets/system-menu-most-used/index.tpl.html",
      "ApplicationId": "" + config.frameworkAppId
    }
  ];

}).call(this);
